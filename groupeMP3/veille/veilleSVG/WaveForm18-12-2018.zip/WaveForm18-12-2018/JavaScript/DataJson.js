function DataJson(jsonUrl) {

    this.init = function(jsonUrl) {
        //recuperation du JSON avec les Info sur la musique
        //MAXIME : Faire le - xhr - qui retourn un objet JSON
        //et commanter le code ci-dessous
        var client = new XMLHttpRequest();
        client.overrideMimeType("application/json");
        client.open('GET', jsonUrl, false);
        client.send(null);
        // console.log(client.responseText);
        var json = JSON.parse(client.responseText);
        // console.log(json);
        // console.log(this.data);
        return clean(json);
    };

    //MAXIME : Traitement des valeur negative et rehaussement des valeur
    //Cette function sera coter serveur
    var clean = function(tab) {
        for (var i = 0; i < tab.data.length; i = i + 2) {
            delete tab.data[i];
        }
        tab.data = tab.data.filter(function(el) {
            return el != null;
        });

        var max = 0;
        for (i = 0; i < tab.data.length; i = i + 1) {
            if (tab.data[i] > max) {
                max = tab.data[i];
            }
        }
        var coef = 255 / max;
        for (i = 0; i < tab.data.length; i = i + 1) {
            if (tab.data[i] <= 1) {
                tab.data[i] = 1;
            } else {
                tab.data[i] = Math.round(tab.data[i] * coef);
            }
        }

        return tab;
    };

    //Cette variable ne sera peut etre pas utile pour le xhr sur la BDD
    this.jsonUrl = jsonUrl; //URL VERS LE FICHIER JSON

    //Variable JSON qui contient toute les information sur la musique
    //Utiliser par la class Player pour verifier que toute les information son présente
    this.json = this.init(this.jsonUrl);

}
