function PlayerConstruct(url, jsonUrl) {

    this.modifNbRect = function(nb) {
        var newTabs = this.json;

        if (nb == 0) {
            console.log("nb = 0");
            var arrayVide = [];
            return arrayVide;
        } else if (nb > this.json.length) {
            return this.json;
        }
        var i = 1;
        while (newTabs.length != nb) {
            var array = [];

            for (var j = 0; j < this.json.length - i; j++) {
                array[j] = (this.json[j] + this.json[j + 1]) / 2;
            }
            newTabs = array;
            i++;
        }
        this.json = newTabs;
    };

    this.url = url;

    //sera remplcer par l'id de la musique pour la requete en BDD ^^
    this.jsonUrl = jsonUrl;

    this.json = new DataJson(this.jsonUrl).json;
    // this.json;

    if (typeof this.json !== 'undefined' && this.json !== null){
        console.log("JSON is define or not null !");
        this.player = new Player(this.json, this.url);
    }else{
        console.log("JSON undefine or Null !");
    }


    //Cree des class pour Player : Info, Button, WaveForm;qs
}
