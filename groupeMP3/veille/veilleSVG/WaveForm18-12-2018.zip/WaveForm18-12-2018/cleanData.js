var clean = function(tab) {
        for (var i = 0; i < tab.data.length; i = i + 2) {
            delete tab.data[i];
        }
        tab.data = tab.data.filter(function(el) {
            return el != null;
        });

        var max = 0;
        for (i = 0; i < tab.data.length; i = i + 1) {
            if (tab.data[i] > max) {
                max = tab.data[i];
            }
        }
        var coef = 255 / max;
        for (i = 0; i < tab.data.length; i = i + 1) {
            if (tab.data[i] <= 1) {
                tab.data[i] = 1;
            } else {
                tab.data[i] = Math.round(tab.data[i] * coef);
            }
        }

        return tab;
    };
